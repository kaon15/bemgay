﻿// Decompiled with JetBrains decompiler
// Type: StardewValley.GenerousEnchantment
// Assembly: Stardew Valley, Version=1.5.6.22018, Culture=neutral, PublicKeyToken=null
// MVID: BEBB6D18-4941-4529-AC12-B54F0C61CC20
// Assembly location: C:\Program Files (x86)\Steam\steamapps\common\Stardew Valley\Stardew Valley.dll

namespace StardewValley
{
  public class GenerousEnchantment : HoeEnchantment
  {
    public override string GetName() => "Generous";

    protected override void _ApplyTo(Item item) => base._ApplyTo(item);

    protected override void _UnapplyTo(Item item) => base._UnapplyTo(item);
  }
}
